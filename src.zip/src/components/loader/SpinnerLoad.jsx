
function SpinnerLoad() {
  return (
    <div className="text-align-left">
      <i class="pi pi-spin pi-sync font-weight-bolder"></i>
    </div>
  );
}

export default SpinnerLoad;
