import { default as authSlice } from "./loginSlice/loginSlice";
import { default as loadingSlice } from "./loadingSlice/loadingSlice";


export {
  authSlice,
  loadingSlice
};
